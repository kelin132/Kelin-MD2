import { getUser, saveUser, requireRegistration, addHistory } from "./database.js";

const WORK_COOLDOWN    = 9 * 60 * 1000;    // 9 min between shifts
const JOB_CHANGE_CD    = 24 * 60 * 60 * 1000; // 24 h between job changes
const FIRE_CHANCE      = 0.30;              // 30 % chance of being fired

const jobs = {
  // ── Regular ──────────────────────────────────────────────
  programmer:   { pay: 3500,  emoji: "👨‍💻", xp: 80,  tier: "Regular" },
  hacker:       { pay: 5500,  emoji: "🎭", xp: 120, tier: "Regular" },
  farmer:       { pay: 2000,  emoji: "👨‍🌾", xp: 40,  tier: "Regular" },
  doctor:       { pay: 4500,  emoji: "⚕️",  xp: 100, tier: "Regular" },
  teacher:      { pay: 2800,  emoji: "👨‍🏫", xp: 60,  tier: "Regular" },
  police:       { pay: 3800,  emoji: "👮",  xp: 90,  tier: "Regular" },
  artist:       { pay: 3200,  emoji: "🎨", xp: 70,  tier: "Regular" },
  chef:         { pay: 3600,  emoji: "👨‍🍳", xp: 80,  tier: "Regular" },
  trader:       { pay: 7000,  emoji: "📈", xp: 150, tier: "Regular" },
  mechanic:     { pay: 3900,  emoji: "🔧", xp: 85,  tier: "Regular" },
  // ── Elite ────────────────────────────────────────────────
  assassin:     { pay: 12000, emoji: "🗡️",  xp: 200, tier: "Elite" },
  kingpin:      { pay: 15000, emoji: "👑", xp: 250, tier: "Elite" },
  spy:          { pay: 9000,  emoji: "🕵️",  xp: 180, tier: "Elite" },
  bountyHunter: { pay: 10500, emoji: "🎯", xp: 190, tier: "Elite" },
  dragonTamer:  { pay: 8500,  emoji: "🐉", xp: 170, tier: "Elite" },
  alchemist:    { pay: 7500,  emoji: "⚗️",  xp: 160, tier: "Elite" },
  warlord:      { pay: 13500, emoji: "⚔️",  xp: 220, tier: "Elite" },
  hiredGun:     { pay: 11000, emoji: "🔫", xp: 195, tier: "Elite" },
  cryptoWhale:  { pay: 18000, emoji: "🐋", xp: 300, tier: "Elite" },
  overlord:     { pay: 20000, emoji: "😈", xp: 350, tier: "Elite" },
};

/** Resolve job key case-insensitively */
function resolveJob(input) {
  const key = input.toLowerCase().replace(/\s+/g, "");
  return Object.keys(jobs).find(k => k.toLowerCase() === key) || null;
}

/** Format ms remaining as  Xh Ym  or  Ym  */
function fmtTime(ms) {
  const m = Math.floor(ms / 60000);
  if (m < 60) return `${m}m`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

/** Jobs board message */
function buildBoard() {
  const reg  = Object.entries(jobs).filter(([, v]) => v.tier === "Regular");
  const elit = Object.entries(jobs).filter(([, v]) => v.tier === "Elite");

  const fmt = ([n, j]) =>
    `  ${j.emoji} *${n}* — $${j.pay.toLocaleString()} *(+${j.xp} xp)*`;

  return (
`꧁━━〔 💼 *J O B S  B O A R D* 〕━━꧂

〔 🔹 *Regular Jobs* 〕
━━━━━━━━━━━━━━━━━━━━━━━
${reg.map(fmt).join("\n")}

〔 💎 *Elite Jobs* 〕
━━━━━━━━━━━━━━━━━━━━━━━
${elit.map(fmt).join("\n")}

━━━━━━━━━━━━━━━━━━━━━━━
📝 Use *.work <jobname>* to apply
🔄 Use *.work change <jobname>* to switch jobs
⏰ Use *.cooldown* to check your timers
⚠️ Every shift has a *30%* chance of being fired!
꧂━━━━━━━━━━━━━━━━━━━━━━꧁`
  );
}

export default {
  name: "work",
  description: "Pick a job, clock in, and earn money — but watch out for the pink slip!",
  category: "economy",
  cooldown: 5,
  usage: ".work | .work jobs | .work <job> | .work change <job>",
  checkJail: true,

  async run({ sock, msg, sender, args }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const jid  = msg.key.remoteJid;
    const user = await getUser(sender);
    const now  = Date.now();

    // ── .work jobs ──────────────────────────────────────────
    if (args[0]?.toLowerCase() === "jobs") {
      return sock.sendMessage(jid, { text: buildBoard() }, { quoted: msg });
    }

    // ── .work change <jobname>  OR  .work <jobname> ─────────
    const isChange = args[0]?.toLowerCase() === "change";
    const jobInput = isChange ? args[1] : args[0];

    if (jobInput) {
      const jobKey = resolveJob(jobInput);
      if (!jobKey) {
        return sock.sendMessage(jid, {
          text:
`❌ *Job not found!*\n\nUse *.work jobs* to see all available positions.`
        }, { quoted: msg });
      }

      // Block job change if within 24 h AND user already has a job AND is NOT fired
      const sinceChange = now - (user.lastJobChange || 0);
      const hasJob      = !!user.job;
      const fired       = user.fired === true;

      if (hasJob && !fired && sinceChange < JOB_CHANGE_CD) {
        const remaining = JOB_CHANGE_CD - sinceChange;
        return sock.sendMessage(jid, {
          text:
`꧁━━〔 🔒 *JOB LOCKED* 〕━━꧂

  You already work as ${jobs[user.job]?.emoji || "❓"} *${user.job}*

  ⏳ You can switch again in *${fmtTime(remaining)}*
  _(Job changes are limited to once per day)_

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`
        }, { quoted: msg });
      }

      // Assign the new job
      user.job           = jobKey;
      user.fired         = false;
      user.lastJobChange = now;
      await saveUser(sender, user);

      const j = jobs[jobKey];
      return sock.sendMessage(jid, {
        text:
`꧁━━〔 ${j.emoji} *HIRED!* 〕━━꧂

  「 Welcome to your new role 」

  ━━━━━━━━━━━━━━━━━━━━━━━
  💼 *Position*   *${jobKey}*
  💰 *Base Pay*   *$${j.pay.toLocaleString()} / shift*
  🔮 *XP Bonus*   *+${j.xp} xp*
  ━━━━━━━━━━━━━━━━━━━━━━━

  ⚔️ Use *.work* every 9 min to collect pay
  ⚠️ Each shift carries a *30% fire risk* — stay sharp!

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`
      }, { quoted: msg });
    }

    // ── .work  (clock in) ───────────────────────────────────

    // No job / fired
    if (!user.job || user.fired) {
      const status = user.fired
        ? "🚨 *You were fired from your last job!*\nPick a new one to get back to work."
        : "😶 *You don't have a job yet!*\nPick one below and start earning.";

      return sock.sendMessage(jid, {
        text: `${status}\n\n${buildBoard()}`
      }, { quoted: msg });
    }

    // Cooldown check
    const sinceWork = now - (user.lastWork || 0);
    if (sinceWork < WORK_COOLDOWN) {
      const remaining = WORK_COOLDOWN - sinceWork;
      const j = jobs[user.job];
      return sock.sendMessage(jid, {
        text:
`꧁━━〔 ⏰ *SHIFT NOT READY* 〕━━꧂

  ${j.emoji} *${user.job}*

  ━━━━━━━━━━━━━━━━━━━━━━━
  🕒 Next shift in  *${fmtTime(remaining)}*
  ━━━━━━━━━━━━━━━━━━━━━━━

  「 Rest up, warrior. The grind awaits. 」

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`
      }, { quoted: msg });
    }

    // ── Process the shift ───────────────────────────────────
    const jobKey = user.job;
    const j      = jobs[jobKey];
    const fired  = Math.random() < FIRE_CHANCE;

    user.lastWork = now;

    if (fired) {
      // Fired — still give partial pay (50 %) as severance
      const severance   = Math.floor(j.pay * 0.5);
      user.money       += severance;
      user.xp           = (user.xp || 0) + Math.floor(j.xp * 0.5);
      user.job          = null;
      user.fired        = true;

      const newLevel = Math.floor(user.xp / 1000) + 1;
      const leveled  = newLevel > (user.level || 1);
      user.level     = newLevel;

      await saveUser(sender, user);
      await addHistory(sender, "work", severance, `Fired from ${jobKey} — severance pay`);

      let text =
`꧁━━〔 🚨 *Y O U ' R E  F I R E D !* 〕━━꧂

  「 The boss just showed you the door... 」

  ━━━━━━━━━━━━━━━━━━━━━━━
  ${j.emoji} *Role*        *${jobKey}*
  💸 *Severance*   *$${severance.toLocaleString()}*
  🔮 *XP*          *+${Math.floor(j.xp * 0.5)}*
  💵 *Balance*     *$${user.money.toLocaleString()}*
  ━━━━━━━━━━━━━━━━━━━━━━━

  📋 Use *.work jobs* to find a new position!

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`;

      if (leveled) text += `\n\n꧁ 🎉 *L E V E L  U P !* — Now *Level ${user.level}* ꧂`;
      return sock.sendMessage(jid, { text }, { quoted: msg });
    }

    // ── Successful shift ────────────────────────────────────
    const bonus  = Math.floor(Math.random() * Math.floor(j.pay * 0.15));
    const total  = j.pay + bonus;
    user.money  += total;
    user.xp      = (user.xp || 0) + j.xp;

    const newLevel = Math.floor(user.xp / 1000) + 1;
    const leveled  = newLevel > (user.level || 1);
    user.level     = newLevel;

    await saveUser(sender, user);
    await addHistory(sender, "work", total, `Worked as ${jobKey}`);

    let text =
`꧁━━〔 ${j.emoji} *M I S S I O N  C O M P L E T E* 〕━━꧂

  「 Another shift survived — barely. 」

  ━━━━━━━━━━━━━━━━━━━━━━━
  💼 *Job*        *${jobKey}*
  💰 *Earned*     *$${total.toLocaleString()}*${bonus > 0 ? `  _(+$${bonus} bonus!)_` : ""}
  🔮 *XP*         *+${j.xp}*
  💵 *Balance*    *$${user.money.toLocaleString()}*
  ━━━━━━━━━━━━━━━━━━━━━━━

  ⚠️ *30% fire risk* each shift — stay on your toes!

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`;

    if (leveled) text += `\n\n꧁ 🎉 *L E V E L  U P !* — Now *Level ${user.level}* ꧂`;
    await sock.sendMessage(jid, { text }, { quoted: msg });
  }
};
