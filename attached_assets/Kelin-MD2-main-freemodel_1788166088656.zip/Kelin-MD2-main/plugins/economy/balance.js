import { getUser, requireRegistration } from "./database.js";

export default {
  name: "balance",
  description: "Check your wallet and bank balance",
  category: "economy",
  usage: ".balance",
  aliases: ["bal", "money", "wallet"],
  cooldown: 6,

  async run({ sock, msg, sender }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const user = await getUser(sender);
    const net  = user.money + user.bank;

    await sock.sendMessage(msg.key.remoteJid, {
      text:
`꧁━━━〔 💰 *W A L L E T* 〕━━━꧂

  👤 *@${sender.split("@")[0]}*

  ━━━━━━━━━━━━━━━━━━━━━━━
  💵 *Cash*      *$${user.money.toLocaleString()}*
  🏦 *Bank*      *$${user.bank.toLocaleString()}*
  💎 *Diamonds*  *${(user.diamonds || 0).toLocaleString()}*
  ━━━━━━━━━━━━━━━━━━━━━━━
  💎 *Net Worth* *$${net.toLocaleString()}*
  ━━━━━━━━━━━━━━━━━━━━━━━

  ⭐ *Level ${user.level}*  〔 🔮 *${user.xp} XP* 〕

  _Wallet max $500B — excess auto-banks_

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`,
      mentions: [sender]
    }, { quoted: msg });
  }
};
