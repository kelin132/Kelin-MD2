import { getUser, saveUser, requireRegistration } from "./database.js";

export default {
  name: "daily",
  description: "Claim your daily reward (24-hour cooldown)",
  category: "economy",
  cooldown: 6,
  usage: ".daily",
  aliases: ["dailyclaim"],

  async run({ sock, msg, sender }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const user     = await getUser(sender);
    const now      = Date.now();
    const cooldown = 24 * 60 * 60 * 1000;

    if (now - (user.lastDaily || 0) < cooldown) {
      const remaining = cooldown - (now - user.lastDaily);
      const hours     = Math.floor(remaining / (60 * 60 * 1000));
      const minutes   = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));

      return sock.sendMessage(msg.key.remoteJid, {
        text:
`꧁━━〔 ⏳ *DAILY REWARD* 〕━━꧂

  すでに受け取り済み！
  *Already claimed today!*

  ━━━━━━━━━━━━━━━━━━━━━━━
  🕐 *Next reward in:*
      *${hours}h ${minutes}m*
  ━━━━━━━━━━━━━━━━━━━━━━━

  🔥 *Don't break your streak!*

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`
      }, { quoted: msg });
    }

    const reward      = 50000 + Math.floor(Math.random() * 50000); // $500–$1000
    user.money        += reward;
    user.lastDaily    = now;
    user.xp           = (user.xp || 0) + 200;

    // Level up every 1000 XP
    const newLevel = Math.floor(user.xp / 1000) + 1;
    const leveled  = newLevel > user.level;
    user.level     = newLevel;

    await saveUser(sender, user);

    let text =
`꧁━━〔 🌟 *DAILY REWARD* 〕━━꧂

  ✅ *Reward claimed, warrior!*

  ━━━━━━━━━━━━━━━━━━━━━━━
  💰 *Received*   *$${reward.toLocaleString()}*
  🔮 *XP Bonus*   *+50*
  💵 *Balance*    *$${user.money.toLocaleString()}*
  ━━━━━━━━━━━━━━━━━━━━━━━

  ⭐ *Level ${user.level}*  🔥 *Streak active!*

꧂━━━━━━━━━━━━━━━━━━━━━━꧁`;
    if (leveled) text += `\n\n꧁ 🎉 *L E V E L  U P !* — Now *Level ${user.level}* ꧂`;

    await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
  }
};
