/**
 * KELIN MD — .bet
 * Gamble a chosen amount of cash. 50% win rate (fair coin flip).
 * Usage: .bet <amount|all|half>
 */
import { getUser, saveUser, requireRegistration, addHistory, maybeAwardDiamonds } from "./database.js";
import { randomChoice, randomChance } from "../../lib/gambling.mjs";
import { parseAmount } from "./parseAmount.js";

const COOLDOWN = 30 * 1000; // 30 seconds between bets

// Possible outcomes — adds flavour without changing the odds
const WIN_LINES = [
  "🎰 Jackpot! The dice rolled in your favour!",
  "🍀 Lucky break! You walked away richer!",
  "🎲 High roller! You doubled down and won!",
  "💫 The stars aligned — you won!",
  "🔥 On fire! You're on a winning streak!",
  "🤑 Easy money! Your instincts were right!",
  "🎯 Bullseye! That's how you do it!",
];

const LOSE_LINES = [
  "💀 Tough luck. The house still wins sometimes.",
  "😬 Ouch. Should've stopped while you were ahead.",
  "🎲 The dice betrayed you. Better luck next time.",
  "💸 Gone in seconds. Easy come, easy go.",
  "🌧️ Rough roll. Your wallet is crying.",
  "😤 So close! But not quite.",
];

export default {
  name: "bet",
  description: "Gamble your cash — 50/50 fair chance",
  category: "economy",
  usage: ".bet <amount | all | half>  ✦ shorthand OK: 10k / 5m / 1b",
  aliases: ["gamble2", "wager"],
  cooldown: 2,
  checkJail: true,

  async run({ sock, msg, sender, args }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const jid  = msg.key.remoteJid;
    const user = await getUser(sender);
    const now  = Date.now();

    // ── Cooldown ──────────────────────────────────────────────────────────
    if (now - (user.lastBet || 0) < COOLDOWN) {
      const secs = Math.ceil((COOLDOWN - (now - user.lastBet)) / 1000);
      return sock.sendMessage(jid, {
        text: `⏳ Slow down! You can bet again in *${secs}s*.`,
      }, { quoted: msg });
    }

    // ── Parse amount ──────────────────────────────────────────────────────
    const raw = args[0]?.toLowerCase();

    if (!raw) {
      return sock.sendMessage(jid, {
        text:
`🎲 *BET*

Usage:
  *.bet <amount>* — e.g. .bet 500 or .bet 10k or .bet 5m
  *.bet all*      — bet everything in your wallet
  *.bet half*     — bet half your wallet
  ✦ Shorthand: *k* = thousand | *m* = million | *b* = billion

💵 Wallet: $${user.money.toLocaleString()}
🎯 Win Rate: *55%* (fair coin flip)`,
      }, { quoted: msg });
    }

    let amount = parseAmount(raw, user.money);

    if (!amount || isNaN(amount) || amount <= 0) {
      return sock.sendMessage(jid, {
        text: "❌ Enter a valid amount. Example: *.bet 500*",
      }, { quoted: msg });
    }

    if (amount > user.money) {
      return sock.sendMessage(jid, {
        text: `❌ You only have *$${user.money.toLocaleString()}* in your wallet.\n\nYou can't bet more than you have.`,
      }, { quoted: msg });
    }

    if (amount < 10) {
      return sock.sendMessage(jid, {
        text: "❌ Minimum bet is *$10*.",
      }, { quoted: msg });
    }

    // ── Resolve outcome — 55% win rate (fair coin flip) ──────────────────
    const won      = randomChance(0.55);
    const diamondReward = maybeAwardDiamonds(user, won ? 0.003 : 0.001, 1, 2);
    const flavour  = won
      ? randomChoice(WIN_LINES)
      : randomChoice(LOSE_LINES);

    user.lastBet = now;

    if (won) {
      user.money += amount;
      user.xp     = (user.xp || 0) + 15;
      await saveUser(sender, user);
      await addHistory(sender, "bet", +amount, `Bet won — wagered $${amount.toLocaleString()}`);

      return sock.sendMessage(jid, {
        text:
`${flavour}

🎲 *BET RESULT — WIN* 🟢

💵 Wagered : $${amount.toLocaleString()}
📈 Won     : +$${amount.toLocaleString()}
💰 Wallet  : $${user.money.toLocaleString()}${diamondReward ? `\n💎 Rare find: +${diamondReward} Diamond${diamondReward === 1 ? "" : "s"}` : ""}`,
      }, { quoted: msg });

    } else {
      user.money = Math.max(0, user.money - amount);
      await saveUser(sender, user);
      await addHistory(sender, "bet", -amount, `Bet lost — wagered $${amount.toLocaleString()}`);

      return sock.sendMessage(jid, {
        text:
`${flavour}

🎲 *BET RESULT — LOSE* 🔴

💵 Wagered : $${amount.toLocaleString()}
📉 Lost    : -$${amount.toLocaleString()}
💰 Wallet  : $${user.money.toLocaleString()}${diamondReward ? `\n💎 Rare find: +${diamondReward} Diamond${diamondReward === 1 ? "" : "s"}` : ""}`,
      }, { quoted: msg });
    }
  },
};
