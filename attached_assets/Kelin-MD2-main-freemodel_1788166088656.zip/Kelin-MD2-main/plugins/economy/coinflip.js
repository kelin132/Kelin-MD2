/**
 * KELIN MD — .coinflip
 * Call heads or tails — 55% win rate with a twist.
 * Usage: .coinflip <heads|tails> <amount>
 */
import { getUser, saveUser, requireRegistration, addHistory, maybeAwardDiamonds } from "./database.js";
import { randomChoice, randomChance } from "../../lib/gambling.mjs";
import { parseAmount } from "./parseAmount.js";

const COOLDOWN = 8 * 1000; // 8 seconds

export default {
  name: "coinflip",
  aliases: ["cf", "flip2"],
  category: "economy",
  cooldown: 6,
  description: "Flip a coin — call it right to double your money! (55% win)",
  usage: ".coinflip <heads|tails> <amount>",
  checkJail: true,

  async run({ sock, msg, sender, args }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const jid   = msg.key.remoteJid;
    const reply = (t) => sock.sendMessage(jid, { text: t }, { quoted: msg });
    const now   = Date.now();
    const user  = await getUser(sender);

    if (now - (user.lastCoinflip || 0) < COOLDOWN) {
      const secs = Math.ceil((COOLDOWN - (now - user.lastCoinflip)) / 1000);
      return reply(`🪙 The coin hasn't landed yet! Try in *${secs}s*.`);
    }

    const call   = (args[0] || "").toLowerCase();
    const rawAmt = (args[1] || "").toLowerCase();

    if (!["heads", "tails", "h", "t"].includes(call) || !rawAmt) {
      return reply(
`🪙 *COIN FLIP*

Usage: *.coinflip <heads|tails> <amount>*
Example: .coinflip heads 1000 or .coinflip h 5m
✦ Shorthand: *k* = thousand | *m* = million | *b* = billion

🎯 Win rate: *55%*
💰 Win: ×2 your bet`
      );
    }

    const normalCall = call === "h" ? "heads" : call === "t" ? "tails" : call;
    let amount = parseAmount(rawAmt, user.money);

    if (!amount || isNaN(amount) || amount < 10) return reply("❌ Minimum bet is *$10*.");
    if (amount > user.money) return reply(`❌ You only have *$${user.money.toLocaleString()}*.`);

    user.lastCoinflip = now;

    const won    = randomChance(0.55);
    const result = won ? normalCall : (normalCall === "heads" ? "tails" : "heads");
    const diamondReward = maybeAwardDiamonds(user, won ? 0.003 : 0.001, 1, 2);
    const coinEmoji = result === "heads" ? "🪙 Heads!" : "🌑 Tails!";

    if (won) {
      user.money += amount;
      user.xp     = (user.xp || 0) + 8;
      await saveUser(sender, user);
      await addHistory(sender, "coinflip", amount, `Coinflip win: ${normalCall}`);
      return reply(`🪙 *COIN FLIP*\n\nYou called *${normalCall}*...\n\n${coinEmoji}\n\n✅ *CORRECT!* +$${amount.toLocaleString()}\n💰 Balance: $${user.money.toLocaleString()}${diamondReward ? `\n💎 Rare find: +${diamondReward} Diamond${diamondReward === 1 ? "" : "s"}` : ""}`);
    } else {
      user.money = Math.max(0, user.money - amount);
      await saveUser(sender, user);
      await addHistory(sender, "coinflip", -amount, `Coinflip loss: ${normalCall}`);
      return reply(`🪙 *COIN FLIP*\n\nYou called *${normalCall}*...\n\n${coinEmoji}\n\n❌ *WRONG!* -$${amount.toLocaleString()}\n💰 Balance: $${user.money.toLocaleString()}${diamondReward ? `\n💎 Rare find: +${diamondReward} Diamond${diamondReward === 1 ? "" : "s"}` : ""}`);
    }
  },
};
