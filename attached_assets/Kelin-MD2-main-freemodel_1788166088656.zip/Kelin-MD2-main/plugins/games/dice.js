import { getUser, saveUser, requireRegistration } from "../economy/database.js";
import { randomInt } from "../../lib/gambling.mjs";
import { parseAmount } from "../economy/parseAmount.js";

export default {
  name: "dicegame",
  description: "Roll dice against the bot — highest roll wins",
  category: "games",
  usage: ".dicegame <bet>",
  aliases: ["dicebet", "rollbet"],
  cooldown: 5,

  async run({ sock, msg, sender, args }) {
    if (!await requireRegistration(sock, msg, sender)) return;

    const user = await getUser(sender);
    const bet  = parseAmount((args[0] || "").toLowerCase(), user.money);

    if (!bet || bet < 50) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: "🎲 *Dice Game*\n\nUsage: *.dicegame <bet>*  — e.g. .dicegame 10k\nMin bet: $50\n✦ Shorthand: k = thousand | m = million | b = billion\nHighest roll wins!"
      }, { quoted: msg });
    }

    if (user.money < bet) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ Not enough money!\n💵 Balance: $${user.money.toLocaleString()}`
      }, { quoted: msg });
    }

    const playerRoll = randomInt(1, 6);
    const botRoll    = randomInt(1, 6);
    const diceMap    = ["⚀","⚁","⚂","⚃","⚄","⚅"];

    // Outcome decided by actual dice rolls — no override
    let result = "";
    if (playerRoll === botRoll) {
      result = "🤝 *TIE! No money lost.*";
      // no money change on tie
    } else if (playerRoll > botRoll) {
      user.money += bet;
      result = "✅ *YOU WIN!*";
    } else {
      user.money = Math.max(0, user.money - bet);
      result = "❌ *Bot wins!*";
    }

    await saveUser(sender, user);

    await sock.sendMessage(msg.key.remoteJid, {
      text:
`🎲 *DICE GAME*

👤 Your roll : ${diceMap[playerRoll-1]} (${playerRoll})
🤖 Bot roll  : ${diceMap[botRoll-1]} (${botRoll})

${result}

💰 Bet    : $${bet.toLocaleString()}
💵 Balance: $${user.money.toLocaleString()}`
    }, { quoted: msg });
  }
};
