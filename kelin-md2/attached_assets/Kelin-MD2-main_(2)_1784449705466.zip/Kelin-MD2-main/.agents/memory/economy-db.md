---
name: Economy DB schema
description: MongoDB users collection fields and helper functions in plugins/economy/database.js
---

## DEFAULTS fields (all users)
money, bank, vault, level, xp, inventory, history (last 10 txns),
lastDaily, lastWeekly, lastMonthly, lastWork, lastCrime, lastRob,
jailed, jailUntil, staffLevel, isPremium, staffImmunity, registered, registeredAt

## Key exports from plugins/economy/database.js
- getUser(id), saveUser(id, data), getAllUsers()
- isRegistered(id), registerUser(id, name), requireRegistration(sock, msg, sender)
- addHistory(id, type, amount, desc) — caps at last 10 entries
- setStaffLevel(id, level), removeStaffLevel(id), getStaffMembers()
- setPremium(id, value), setStaffImmunity(id, value)
- jailUser(id, durationMs), unjailUser(id)
- deletePlayer(id), resetPlayer(id), setPlayerFields(id, fields)

**Why:** Single source of truth — all plugins import from here, not from mongo directly.

## History type strings
daily, weekly, monthly, work, crime, rob, rob_victim, deposit, withdraw,
vault_deposit, vault_withdraw, donate_out, donate_in, transfer_out, transfer_in,
convert, shop, slots, coinflip, dice, jail, unjail, reset
