---
name: GitHub push auth
description: How to authenticate git push — token handling rules
---

## Rule
Never paste a GitHub PAT directly in chat. GitHub scans chat/commit logs and auto-revokes any token it finds.

**Why:** Happened twice in this project — tokens pasted in chat were revoked within minutes.

**How to apply:**
1. Use `requestSecrets({ keys: ["GITHUB_TOKEN"] })` to prompt the user via Replit's secure secrets UI.
2. Push with `git push "https://kelin132:${GITHUB_TOKEN}@github.com/kelin132/Kelin-MD2.git" main`
3. The env var is injected at shell level — never interpolated visibly in logs.

## Repo details
- Remote: https://github.com/kelin132/Kelin-MD2.git
- Branch: main (tracking origin/main)
- Username: kelin132
- Required permission: Fine-grained PAT, Contents: Read & Write on Kelin-MD2
