---
name: Permissions system
description: How owner/staff/mod/premium/jail checks work — JID-based, DB-backed
---

## Rule
Owner check must compare full JIDs (`263xxx@s.whatsapp.net`), not substring/number match.

**Why:** In groups, `msg.key.participant` is the sender JID. A loose `.includes()` on digits could false-positive. JID comparison is exact.

**How to apply:** `lib/permissions.mjs` builds `ownerJid = digits + "@s.whatsapp.net"` and compares `sender === ownerJid`. All permission checks go through `getPermissions(sender, ownerNumber)` which returns `{ isOwner, isStaff, isMod, isPremium, isJailed, staffLevel, staffImmunity }`.

## Staff levels (stored in users.staffLevel)
- 0 = regular user
- 1 = mod (isMod: true)
- 2 = staff (isStaff: true)
- 3 = admin
- 99 = owner sentinel (not stored in DB)

## Plugin flags
- `isOwner: true` — owner only
- `isStaff: true` — staff (≥2) or owner
- `isMod: true` — mod (≥1), staff, or owner
- `isPremium: true` — premium, mod, staff, or owner
- `checkJail: true` — block jailed users (unless staffImmunity)

## routeMessage
Calls `getPermissions()` once per message (single DB round-trip), passes full context to plugin.run(). Auto-unjails users whose jailUntil has expired.
