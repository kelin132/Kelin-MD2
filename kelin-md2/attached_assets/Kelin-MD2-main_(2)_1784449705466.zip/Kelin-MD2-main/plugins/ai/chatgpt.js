export default {
  name: "chatgpt",
  description: "Chat with ChatGPT AI",
  category: "ai",
  usage: ".chatgpt <prompt>",
  aliases: ["gpt", "ai"],
  cooldown: 10,
  isOwner: false,
  isAdmin: false,
  isPremium: false,
  version: "1.0.0",

  async run({ sock, msg, text }) {

    const jid = msg.key.remoteJid;
    const apiKey = process.env.OPENAI_API_KEY;

    if (!text) {
      return sock.sendMessage(jid, {
        text: "❌ Usage: .chatgpt <question>\n\nExample:\n.chatgpt What is artificial intelligence?"
      });
    }

    if (!apiKey) {
      return sock.sendMessage(jid, {
        text: "❌ OpenAI API key not found.\n\nAdd this to your .env file:\n\nOPENAI_API_KEY=your_api_key_here"
      });
    }

    try {

      await sock.sendPresenceUpdate("composing", jid);

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "system",
                content: "You are KELIN-MD AI. Give helpful, friendly and short answers."
              },
              {
                role: "user",
                content: text
              }
            ],
            max_tokens: 1000,
            temperature: 0.7
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error?.message || "OpenAI API request failed"
        );
      }

      const reply = data.choices?.[0]?.message?.content;

      if (!reply) {
        throw new Error("No AI response received");
      }

      await sock.sendPresenceUpdate("paused", jid);

      await sock.sendMessage(jid, {
        text: `🤖 *KELIN AI*\n\n${reply}`
      });


    } catch (error) {

      console.error("CHATGPT ERROR:", error);

      await sock.sendPresenceUpdate("paused", jid);

      await sock.sendMessage(jid, {
        text: `❌ ChatGPT Error:\n\n${error.message}`
      });
    }
  },
};